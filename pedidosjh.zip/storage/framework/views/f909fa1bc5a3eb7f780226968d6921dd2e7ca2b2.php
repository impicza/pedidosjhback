<!DOCTYPE html>
<html>
<head>

	<title>Pedidos JH</title>
<style>
	.table {
	  font-family: arial, sans-serif;
	  border-collapse: collapse;
	  
	}

	.table-info {
	  font-family: arial, sans-serif;
	}

	p,h3,h1,h4{
		font-family: arial, sans-serif;
	}

	table{
		width: 100%;
		margin-top: 10px 0px;
	}

	table p{
		margin: 0px;
	}

	table h3{
		margin: 0px;
	}

	.table td, .table th {
	  border: 1px solid #dddddd;
	  text-align: left;
	  padding: 8px;
	}

	.title-table{
		font-size: 14px;
	}

	.table-even tr:nth-child(even) {
	  background-color: #dddddd;
	}

	.w100{
		width: 100%;
		display: table;
	}

	.w50{
		width: 48%;
	}

	.text-center{
		text-align: center;
	}

	.table-font td,.table-font th{
		font-size: 10px;
		margin: 3px 0px;
		padding: 3px;
	}

	.text-footer{
		font-size: 12px;
	}

	.table-info p{
		font-size: 14px;
	}
</style>
</head>
<body>
	<h3 style="text-align:center;">Pedido de : <?php echo e($usuario->name); ?></h3> 
	<h4 style="text-align:center;">Fecha : <?php echo e($pedido->created_at); ?></h3> 

	</br>

	<div>
		<h4>Cerdo</h4>
		<table class="table table-even table-font">
			<thead>
				<tr>
					<th style="width:25%;"><span class="title-table">Producto</span></th>
					<th style="width:25%;"><span class="title-table">Unidad</span></th>
					<th style="width:25%;"><span class="title-table">Cantidad</span></th>
					<th style="width:25%;"><span class="title-table">Peso Despachado</span></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $productosCerdo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($element->producto_nombre); ?></td>
						<td><?php echo e($element->unidad_nombre); ?></td>
						<td><?php echo e($element->cantidad); ?></td>
						<td></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
		</table>
	</div>

	<div>
		<h4>Res</h4>
		<table class="table table-even table-font">
			<thead>
				<tr>
					<th style="width:25%;"><span class="title-table">Producto</span></th>
					<th style="width:25%;"><span class="title-table">Unidad</span></th>
					<th style="width:25%;"><span class="title-table">Cantidad</span></th>
					<th style="width:25%;"><span class="title-table">Peso Despachado</span></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $productosRes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($producto->producto_nombre); ?></td>
						<td><?php echo e($producto->unidad_nombre); ?></td>
						<td><?php echo e($producto->cantidad); ?></td>
						<td></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
		</table>
	</div>

	<br>
	<br>
	
</body>
</html><?php /**PATH C:\xampp\htdocs\pedidosjh\resources\views/pdf/pedido.blade.php ENDPATH**/ ?>